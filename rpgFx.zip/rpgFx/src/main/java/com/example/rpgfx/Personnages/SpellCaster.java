package com.example.rpgfx.Personnages;

public abstract class SpellCaster extends Hero {
}
