package com.example.rpgfx;

import com.example.rpgfx.Personnages.*;
import com.example.rpgfx.Personnages.Team;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class ConsoleParser implements InputParser{
    public Scanner scanner;
    private Game game;

    public ConsoleParser(Game game){
        this.game = game;

        this.scanner = new Scanner(System.in);
    }

    @Override
    public void bienvenu() {
        System.out.println("Bienvenu dans mon jeu de RPG, j'espere que vous allez bien vous amuser !\n");
        this.nombreDeHeros();
    }

    @Override
    public void nombreDeHeros() {
        System.out.println("Choisis le nombre de héros que tu veux!");
        int nombre = demandeNombre(this.scanner);
        while(nombre==0){
            System.out.println("Veuillez entrer un nombre positif");
            nombre = demandeNombre(this.scanner);
        }
        this.game.setTotalHero(nombre);
        this.game.boucleHero(1);
    }


    @Override
    public void demandeHero(int numero) {
        //System.out.println("Vous allez maintenant creer vos heros");

        System.out.println("Veuillez choisir la classe du hero numero "+numero);
        System.out.println("Warrior (1)");
        System.out.println("Hunter  (2)");
        System.out.println("Mage    (3)");
        System.out.println("Healer  (4)");
        int nombre = demandeNombre(this.scanner);
        while(nombre != 1 && nombre !=2 && nombre != 3 && nombre!=4){
            System.out.println("Veuillez entrer le chiffre 1, 2, 3 ou 4");
            nombre = demandeNombre(this.scanner);
        }

        this.nomHero(nombre);

    }

    @Override
    public void nomHero(int nombre) {
        System.out.println("Veuillez entrer le nom de votre hero");
        String nom = this.scanner.nextLine();
        this.game.creerHero(nombre,nom);

    }

    @Override
    public void nomTeam() {
        System.out.println("Veuillez entrer un nom pour votre equipe de hero");
        String nom = this.scanner.nextLine();
        this.game.createTeam(nom);
    }


    @Override
    public void afficheTeam(Team team) {
        System.out.println("\n--------------------------------------------------------\n");

        if(team.getTeamList().size() >0){
            Combatant combatant0 = team.getTeamList().get(0);
            if(combatant0 instanceof Hero){
                System.out.println("Voici vos heros");
                for(Combatant combatant : team.getTeamList()){
                    Hero hero = (Hero)combatant;
                    System.out.println("Classe : "+ hero.getHeroType().toString()+
                            " | Nom : "+ hero.getName()+" | Life points "+hero.getLifePoints());

                }
                this.game.creerEnemy(this.game.getTotalHero());

            }else{

                System.out.println("Voici vos ennemis");
                for(Combatant combatant : team.getTeamList())
                System.out.println("Nom enemy : "+combatant.getName()+" | Life points : "+combatant.getLifePoints());
                this.game.ordre();

            }

        }


    }

    @Override
    public void annonceTour() {
        System.out.println("\nC'est le tour de "+this.game.getCombattantActuel().getName());
        System.out.println("\n"+"-".repeat(30));
        this.choixAction();
    }

    @Override
    public void choixAction(){
        if(this.game.getCombattantActuel() instanceof Hero){
            System.out.println("Quelle action veux tu executer ?");
            System.out.println("(1) Attaque");
            System.out.println("(2) Objet");
            int input = demandeNombre(this.scanner);
            while(input!= 1 && input!=2){
                System.out.println("Veuillez entrer 1 ou 2");
                input = demandeNombre(this.scanner);
            }
            if(input==1){
                this.choixCible();
            }else {
                this.choixObjet();
            }

        }else{
            int i = (int)(Math.random()*this.game.getTeamHero().listeVivant().size()-1);
            Combatant cible = this.game.getTeamHero().listeVivant().get(i);
            this.game.executeAttack(cible);
        }
    }

    @Override
    public void choixCible() {
        System.out.println("Veuillez choir votre cible");
        for(Combatant combatant : this.game.getTeamEnemy().listeVivant()){
            int indice = this.game.getTeamEnemy().listeVivant().indexOf(combatant)+1;
            System.out.println("("+indice+") "+combatant.getName()+" | Life points : "+combatant.getMaxLifePoints());
        }
        int input = demandeNombre(this.scanner);
        while(input<1 || input>this.game.getTeamEnemy().listeVivant().size()+1){
            System.out.println("Veuillez entrer une entree valide");
            input = demandeNombre(this.scanner);
        }
        Combatant cible = this.game.getTeamEnemy().listeVivant().get(input);
        this.game.executeAttack(cible);

    }

    @Override
    public void choixObjet() {

    }


    public static boolean onlyNumbers(String entree){
        List<Character> chiffre = Arrays.asList('1','2','3','4','5','6','7','8','9','0');
        char[] entreeList = entree.toCharArray();
        for(char c : entreeList){
            if(!chiffre.contains(c)){
                return false;
            }
        }
        return true;
    }

    public static int demandeNombre(Scanner scanner){
        String entree = scanner.nextLine();
        while(!onlyNumbers(entree)){
            System.out.println("Veuillez donner une entree valide");
            entree = scanner.nextLine();
        }
        return Integer.parseInt(entree);

    }


}
