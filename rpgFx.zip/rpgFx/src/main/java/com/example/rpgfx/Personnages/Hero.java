package com.example.rpgfx.Personnages;

import com.example.rpgfx.Personnages.Combatant;

public abstract class Hero extends Combatant {




    protected HeroType heroType;



    public HeroType getHeroType() {
        return heroType;
    }
}


