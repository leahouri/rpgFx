package com.example.rpgfx.Objets;

public class Weapon extends Item {
   public Weapon(String weaponName, int weaponCapacity){

   }
}
