package com.example.rpgfx;

import com.example.rpgfx.Personnages.*;


import java.util.ArrayList;
import java.util.Scanner;

public class Game {

    private InputParser inputParser;
    private Team teamHero;
    private Team teamEnemy;
    private int totalHero;
    private ArrayList<Combatant> ordreTour = new ArrayList<Combatant>();
    private Combatant combattantActuel;
    

    public Game(){

        this.teamEnemy = new Team("Equipe Monstre");


    }

    public void setInputParser(InputParser inputParser) {
        this.inputParser = inputParser;
    }

    public void start(){
        this.inputParser.nomTeam();
        //this.teamHero = new Team(teamNom);

        //this.inputParser.nombreDeHeros();






    }
    public void createTeam(String nomTeam){
        this.teamHero = new Team(nomTeam);
        this.inputParser.bienvenu();
    }



    public  void boucleHero(int actuel){
        if(actuel<=this.totalHero){
            this.inputParser.demandeHero(actuel);
        }else {
            this.inputParser.afficheTeam(teamHero);
        }
    }

    public void creerHero(int nombre, String nom){
        if(nombre ==1){
            //alors warrior
            new Warrior(nom,1000, this.teamHero);
        }else if(nombre == 2){
            //alors Hunter
            new Hunter(nom, 1000, this.teamHero);
        }else if(nombre == 3){
            //alors mage
            new Mage(nom,1000,this.teamHero);

        }else if(nombre == 4){
            //alors healer
            new Healer(nom, 1000, this.teamHero);
        }
        this.boucleHero(this.teamHero.getTeamList().size()+1);

    }

    public void setTotalHero(int totalHero) {
        this.totalHero = totalHero;
    }

    public int getTotalHero() {
        return totalHero;
    }

    public void creerEnemy(int nombreHero){
        for(int i = 0; i< nombreHero; i = i+1){
            new Enemy("Monstre",900,this.teamEnemy);

        }
        this.inputParser.afficheTeam(this.teamEnemy);


    }

    public void ordre(){
        for(int i = 0; i<this.totalHero;i=i+1){
            this.ordreTour.add(this.teamHero.getTeamList().get(i));
            this.ordreTour.add(this.teamEnemy.getTeamList().get(i));
        }
        this.nextCombattant();
        this.inputParser.annonceTour();
    }

    public Combatant getCombattantActuel() {
        return combattantActuel;
    }

    public Team getTeamEnemy() {
        return teamEnemy;
    }

    public Team getTeamHero() {
        return teamHero;
    }

    public void executeAttack(Combatant cible){

    }

    public void nextCombattant(){
        int i = this.ordreTour.indexOf(this.combattantActuel);
        if(i+1==this.ordreTour.size()){
            i = 0;
        }else {
            i = i+1;
        }
        this.combattantActuel = this.ordreTour.get(i);
    }



}

