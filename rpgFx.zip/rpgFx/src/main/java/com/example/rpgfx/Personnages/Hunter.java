package com.example.rpgfx.Personnages;

public class Hunter extends Hero {
    public Hunter(String name, int lifePoints, Team team){
        this.name = name;
        this.lifePoints = lifePoints;
        this.maxLifePoints = 1000;
        this.maxMana = 1000;
        this.def = 0.5f;
        this.force = 10;
        this.team = team;
        this.team.ajoutCombatant(this);
        this.heroType = HeroType.HUNTER;
    }
}
