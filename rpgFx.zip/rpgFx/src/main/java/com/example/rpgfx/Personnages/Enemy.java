package com.example.rpgfx.Personnages;

import com.example.rpgfx.Personnages.Combatant;

public class Enemy extends Combatant {

    public Enemy(String name, int lifePoints, Team team){
        this.name = name;
        this.lifePoints = lifePoints;
        this.maxLifePoints = 900;
        this.maxMana = 800;
        this.def = 0.1f;
        this.force = 8;
        this.team = team;
        this.team.ajoutCombatant(this);


}
    }

