package com.example.rpgfx;

import com.example.rpgfx.Personnages.Team;

public class GuiParser implements InputParser{
    @Override
    public void bienvenu() {

    }

    @Override
    public void nombreDeHeros() {

    }

    @Override
    public void demandeHero(int nombreHero) {
    }

    @Override
    public void nomHero(int numero) {
    }

    @Override
    public void nomTeam() {

    }


    @Override
    public void afficheTeam(Team team) {

    }

    @Override
    public void annonceTour() {

    }

    @Override
    public void choixAction() {

    }

    @Override
    public void choixCible() {

    }

    @Override
    public void choixObjet() {

    }


}
